// React app placeholder
const BASE_URL = 'https://your-backend-url';