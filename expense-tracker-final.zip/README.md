
# Expense Tracker Full-Stack Project

This is a full-stack Expense Tracker project ready for submission.

## Stack
- Frontend: React.js
- Backend: Spring Boot
- Database: MongoDB Atlas
- Auth: JWT (planned)

## Final Submission Instructions

### 1. Backend (Spring Boot)
- Replace MongoDB Atlas placeholders (<username> / <password>) in backend/src/main/resources/application.properties.
- Push backend/ folder to GitHub.
- Optional: Add JWT auth placeholders if required.
- Test locally: mvn spring-boot:run → verify CRUD endpoints work.

### 2. Frontend (React)
- Push frontend/ folder to GitHub.
- Update API URL in React code (App.js) to point to the deployed backend URL (or local backend for testing).
- Test locally: npm install && npm start → verify frontend communicates with backend.

### 3. Deployment (Optional Live Demo)
- Deploy backend on Render or Heroku (free tier).
- Deploy frontend on Vercel or Netlify (free tier).
- Test frontend → backend → database flow.
- Confirm CORS is properly configured.

### 4. README.md
- Ensure instructions are clear for running locally and deploying.
- Include AI tool mention: OpenAI GPT-4 helped scaffold the project.
- Include notes for JWT auth, charts, and planned enhancements (even if not implemented).

### 5. ZIP for Submission
- Ensure frontend/, backend/, and README.md are included.
- Optional: Include .gitignore files for both frontend and backend.

## AI Tool Usage
Project scaffold, code structure, and README documentation were generated with the assistance of **OpenAI GPT-4**.
