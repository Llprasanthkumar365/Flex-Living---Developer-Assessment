# Expense Tracker Starter

This is a minimal **starter** full-stack project (frontend + backend) to track expenses.

## Stack (defaults)
- Frontend: React
- Backend: Java Spring Boot
- Database: MongoDB (can be switched to PostgreSQL; code uses Spring Data MongoDB)
- Auth: JWT (placeholders & notes included in README; full auth implementation is optional)

## What is included
- `backend/` — Spring Boot application with Expense model, repository, and REST controller (CRUD + pagination stub).
- `frontend/` — React app skeleton with pages to list and add expenses.
- `README.md` — this file.
- `.gitignore`

## Quick start (local)

### Prerequisites
- Java 17+ and Maven
- Node 18+
- MongoDB running locally (default: mongodb://localhost:27017/expensedb)

### Backend
1. Open terminal:
```bash
cd backend
mvn spring-boot:run
```
2. Server will run on `http://localhost:8080`.  
API endpoints:
- `GET /api/expenses` — list (supports `?page=` & `?size=` query params)
- `POST /api/expenses` — create
- `GET /api/expenses/{id}` — read
- `PUT /api/expenses/{id}` — update
- `DELETE /api/expenses/{id}` — delete

### Frontend
1. Open separate terminal:
```bash
cd frontend
npm install
npm start
```
2. App runs on `http://localhost:3000` and communicates with backend at `http://localhost:8080` (CORS enabled).

## JWT / Auth
A simple JWT authentication flow is *planned* but not fully wired in this starter. See `backend/README-JWT.md` which explains recommended steps and code pointers to enable JWT-based auth with refresh tokens.

## Deploy
- You can dockerize backend and frontend and use `docker-compose` to run MongoDB + backend + frontend. Not included in starter to keep size small.

## Next steps / customization suggestions
- Add User entity + AuthController + JWT filters (backend).
- Add HTTP-only cookie handling & refresh tokens.
- Improve frontend: add login/register screens, protected routes, charts (Chart.js) and insights page.
- Add unit/integration tests.

Enjoy — extract the ZIP and push to your GitHub repo.
