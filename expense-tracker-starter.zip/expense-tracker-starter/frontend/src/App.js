import React from 'react';
import ExpenseList from './components/ExpenseList';
import AddExpense from './components/AddExpense';

function App(){
  return (
    <div style={{maxWidth:800, margin:'0 auto', padding:20}}>
      <h1>Expense Tracker (Starter)</h1>
      <AddExpense />
      <hr />
      <ExpenseList />
    </div>
  );
}

export default App;
