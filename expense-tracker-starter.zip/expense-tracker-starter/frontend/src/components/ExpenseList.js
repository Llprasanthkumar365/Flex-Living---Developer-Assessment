import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function ExpenseList(){
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/expenses')
      .then(res => setExpenses(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h2>All Expenses</h2>
      {expenses.length===0 && <p>No expenses yet.</p>}
      <ul>
        {expenses.map(e => (
          <li key={e.id}>
            <strong>{e.title}</strong> — {e.category} — ₹{e.amount} — {e.date}
          </li>
        ))}
      </ul>
    </div>
  );
}
