import React, {useState} from 'react';
import axios from 'axios';

export default function AddExpense(){
  const [title,setTitle]=useState('');
  const [category,setCategory]=useState('');
  const [amount,setAmount]=useState('');

  const submit = async (e) => {
    e.preventDefault();
    try{
      const payload = { title, category, amount: parseFloat(amount), date: new Date().toISOString().slice(0,10), notes: '' };
      await axios.post('http://localhost:8080/api/expenses', payload);
      setTitle(''); setCategory(''); setAmount('');
      window.location.reload();
    }catch(err){
      console.error(err);
      alert('Error creating expense');
    }
  };

  return (
    <form onSubmit={submit} style={{display:'flex', gap:8, alignItems:'center'}}>
      <input required placeholder='Title' value={title} onChange={e=>setTitle(e.target.value)} />
      <input required placeholder='Category' value={category} onChange={e=>setCategory(e.target.value)} />
      <input required placeholder='Amount' value={amount} onChange={e=>setAmount(e.target.value)} />
      <button type='submit'>Add</button>
    </form>
  );
}
