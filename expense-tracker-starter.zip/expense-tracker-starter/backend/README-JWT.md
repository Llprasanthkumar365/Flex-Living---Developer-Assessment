# JWT Integration Notes (backend)

This starter does not include a full JWT authentication flow. Recommended next steps:

1. Add User model and `UserRepository`.
2. Add `AuthController` with `/api/auth/register` and `/api/auth/login`.
3. Use `io.jsonwebtoken:jjwt-api` (or `com.auth0:java-jwt`) to generate and validate tokens.
4. Create a `JwtFilter` which inspects Authorization header (Bearer <token>) and sets SecurityContext.
5. Configure `SecurityFilterChain` with `HttpSecurity` to protect `/api/expenses/**` endpoints.
6. For refresh tokens, store refresh token records in DB or use rotating refresh tokens with HTTP-only cookies.

There are many tutorials online for "Spring Boot JWT tutorial". If you want, I can add the full implementation in the backend in the next iteration.
