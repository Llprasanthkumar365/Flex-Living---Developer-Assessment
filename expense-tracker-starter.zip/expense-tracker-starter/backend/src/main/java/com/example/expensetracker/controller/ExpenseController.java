package com.example.expensetracker.controller;

import com.example.expensetracker.model.Expense;
import com.example.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseRepository repo;

    @GetMapping
    public List<Expense> list(@RequestParam(defaultValue = "0") int page,
                              @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        // MongoRepository doesn't return Page without extra setup; returning all for simplicity
        return repo.findAll();
    }

    @PostMapping
    public Expense create(@RequestBody Expense expense) {
        return repo.save(expense);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Expense> get(@PathVariable String id) {
        Optional<Expense> e = repo.findById(id);
        return e.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Expense> update(@PathVariable String id, @RequestBody Expense expense) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setTitle(expense.getTitle());
                    existing.setAmount(expense.getAmount());
                    existing.setCategory(expense.getCategory());
                    existing.setDate(expense.getDate());
                    existing.setNotes(expense.getNotes());
                    repo.save(existing);
                    return ResponseEntity.ok(existing);
                }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        return repo.findById(id).map(e -> {
            repo.deleteById(id);
            return ResponseEntity.noContent().<Void>build();
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
